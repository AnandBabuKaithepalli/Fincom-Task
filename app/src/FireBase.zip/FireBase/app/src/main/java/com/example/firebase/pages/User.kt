package com.example.firebase.pages

data class User (
    val name:String,
    val email:String,
    val password:String,
    val uniqueid:String
)